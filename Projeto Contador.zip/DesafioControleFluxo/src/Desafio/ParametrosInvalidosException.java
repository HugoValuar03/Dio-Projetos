package Desafio;

public class ParametrosInvalidosException extends Exception{

}
